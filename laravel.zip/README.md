php artisan make:controller categoryCcontroller
php artisan optimize (route create korar somoy)
php artisan serve
 php artisan make:model skills -m