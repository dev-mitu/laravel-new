<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Skill page</title>
</head>
<body>
    <h2>This is skill page</h2>
    
    <!-- Button to Create Skill -->
    <a href="{{ route('skills.create') }}">
        <button>Create Skill</button>
    </a>

</body>
</html>

