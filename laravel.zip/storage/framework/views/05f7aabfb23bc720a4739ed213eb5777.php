<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h3>
Web design encompasses many different skills and disciplines in the production and maintenance of websites. The different areas of web design include web graphic design; user interface design; authoring, including standardised code and proprietary software; user experience design; and search engine optimization. 
Wikipedia</h3>
</body>
</html><?php /**PATH C:\Users\WALTON\Desktop\laravel-new\resources\views/others.blade.php ENDPATH**/ ?>